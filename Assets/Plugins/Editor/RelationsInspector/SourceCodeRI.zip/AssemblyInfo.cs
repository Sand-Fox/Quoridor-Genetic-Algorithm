using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle( "RelationsInspector" )]
[assembly: AssemblyDescription( "Editor plugin for Unity 4.3 and higher. Graphical visualiztion of relations." )]
[assembly: AssemblyConfiguration( "" )]
[assembly: AssemblyCompany( "seldomU" )]
[assembly: AssemblyProduct( "RelationsInspector" )]
[assembly: AssemblyCopyright( "Copyright ©  2016" )]
[assembly: AssemblyTrademark( "" )]
[assembly: AssemblyCulture( "" )]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible( false )]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid( "443be73c-10d9-48b3-9f43-5f22e4c45fa6" )]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion( "1.1.5" )]
//[assembly: AssemblyFileVersion( "1.0.0.0" )]
