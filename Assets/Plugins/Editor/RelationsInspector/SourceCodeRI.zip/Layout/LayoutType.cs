
namespace RelationsInspector
{
	public enum LayoutType { Graph, Tree }
}
